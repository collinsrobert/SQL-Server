## Copyright (c) Microsoft Corporation.
## Licensed under the MIT license.


<#
.SYNOPSIS
    SQL LogScout allows you to collect diagnostic logs from your SQL Server system to help resolve technical problems.
.DESCRIPTION
.LINK 
https://github.com/microsoft/SQL_LogScout#examples

.EXAMPLE
   SQL_LogScout.ps1
.EXAMPLE
    SQL_LogScout.ps1 -Scenario GeneralPerf
.EXAMPLE
    SQL_LogScout.ps1 -Scenario DetailedPerf -ServerName "SQLInstanceName" -CustomOutputPath "UsePresentDir" -DeleteExistingOrCreateNew "DeleteDefaultFolder"
.EXAMPLE
    SQL_LogScout.ps1 -Scenario "AlwaysOn" -ServerName "DbSrv" -CustomOutputPath "PromptForCustomDir" -DeleteExistingOrCreateNew "NewCustomFolder" -DiagStartTime "2000-01-01 19:26:00" -DiagStopTime "2020-10-29 13:55:00"
.EXAMPLE
   SQL_LogScout.ps1 -Scenario "GeneralPerf+AlwaysOn+BackupRestore" -ServerName "DbSrv" -CustomOutputPath "d:\log" -DeleteExistingOrCreateNew "DeleteDefaultFolder" -DiagStartTime "01-01-2000" -DiagStopTime "04-01-2021 17:00" -InteractivePrompts "Quiet"
#>


#=======================================Script parameters =====================================
param
(
    # DebugLevel parameter is deprecated
    # SQL LogScout will generate *_DEBUG.LOG with verbose level 5 logging for all executions
    # to enable debug messages in console, modify $global:DEBUG_LEVEL in LoggingFacility.ps1
    
    #help parameter is optional parameter used to print the detailed help "/?, ? also work"
    [Parameter(ParameterSetName = 'help',Mandatory=$false)]
    [Parameter(Position=0)]
    [switch] $help,

    #Scenario an optional parameter that tells SQL LogScout what data to collect
    [Parameter(Position=1,HelpMessage='Choose a plus-sign separated list of one or more of: Basic,GeneralPerf,DetailedPerf,Replication,AlwaysOn,Memory,DumpMemory,WPR,Setup,NoBasic. Or MenuChoice')]
    [string[]] $Scenario=[String]::Empty,

    #servername\instnacename is an optional parameter since there is code that auto-discovers instances
    [Parameter(Position=2)]
    [string] $ServerName = [String]::Empty,

    #Optional parameter to use current directory or specify a different drive and path 
    [Parameter(Position=3,HelpMessage='Specify a valid path for your output folder, or type "UsePresentDir"')]
    [string] $CustomOutputPath = "PromptForCustomDir",

    #scenario is an optional parameter since there is a menu that covers for it if not present
    [Parameter(Position=4,HelpMessage='Choose DeleteDefaultFolder|NewCustomFolder')]
    [string] $DeleteExistingOrCreateNew = [String]::Empty,

    #specify start time for diagnostic
    [Parameter(Position=5,HelpMessage='Format is: "2020-10-27 19:26:00"')]
    [string] $DiagStartTime = "0000",
    
    #specify end time for diagnostic
    [Parameter(Position=6,HelpMessage='Format is: "2020-10-27 19:26:00"')]
    [string] $DiagStopTime = "0000",

    #specify quiet mode for any Y/N prompts
    [Parameter(Position=7,HelpMessage='Choose Quiet|Noisy')]
    [string] $InteractivePrompts = "Noisy",

    [Parameter(Position=8,HelpMessage='Provide 0 for no repetition | Specify >0 for as many times as you want to run the script. Default is 0.')]
    [int] $RepeatCollections = 0
    
)

function Test-PowerShellVersionAndHost()
{
    #check for version 4-6 and not ISE 
    $psversion_maj = (Get-Host).Version.Major
    $psversion_min = (Get-Host).Version.Minor
    $pshost_name = (Get-Host).Name

    if (($psversion_maj -lt 4) -or ($psversion_maj -ge 7))
    {
        Microsoft.PowerShell.Utility\Write-Host "Please use a supported PowerShell version 4.x, 5.x or 6.x. Your current verion is $psversion_maj.$psversion_min." -ForegroundColor Yellow
        Microsoft.PowerShell.Utility\Write-Host "Exiting..." -ForegroundColor Yellow
        exit 7654321
    }
    elseif ($pshost_name -match "ISE") 
    {
        Microsoft.PowerShell.Utility\Write-Host "The 'Windows PowerShell ISE Host' is not supported as a PowerShell host for SQL LogScout." -ForegroundColor Yellow
        Microsoft.PowerShell.Utility\Write-Host "Please use a PowerShell console (ConsoleHost)"  -ForegroundColor Yellow
        Microsoft.PowerShell.Utility\Write-Host "Exiting..." -ForegroundColor Yellow
        exit 8765432
    }

    else {
        Write-Host "Launching SQL LogScout..."
    }
}

# create a temporary log file to store the output of the repeated executions
$script:temp_output_sqllogscout = $env:temp + "\SQL_LogScout_Repeated_Execution_" + (Get-Date).ToString('yyyyMMddhhmmss') + ".txt"
$script:search_pattern = $env:temp + "\SQL_LogScout_Repeated_Execution_*.txt"

function Write-SQLLogScoutTempLog()
{
    param 
    ( 
        [Parameter(Position=0,Mandatory=$true)]
        [Object]$Message
    )

    try
    {        
        [String]$strMessage = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
        $strMessage += "	: "
        $strMessage += [string]($Message)

        Add-Content -Path $script:temp_output_sqllogscout -Value $strMessage
    }
	catch
	{
		Write-Host "Exception writing to the temp log file: $script:temp_output_sqllogscout. Error: $($_.Exception.Message)"
	}
    
}


# the main script
try 
{
    # validate the minimum version of PowerShell and PowerShell host (not ISE)
    Test-PowerShellVersionAndHost

    # check if the temp log file exists, if it does, then delete it
    if (Test-Path -Path $script:search_pattern)
    {
        Remove-Item -Path $script:search_pattern -Force
    }

    # set the output folders array to store all the folders which are created by SQL LogScout in repeated mode
    $script:output_folders_multiple_runs = @()

    # set the execution counter to 0
    [int] $execution_counter = 0

    # If the user wants to run the main script multiple times, then we will loop through multiple times with max = RepeatCollections
    # if RepeatCollections is set to 0, then we will run the script only once (we don't want to repeat)

    do
    {

        # changes the directory to the location of the script, which is the root of SQL LogScout and stores on the stack
        Push-Location -Path $PSScriptRoot

        # Change the location to the Bin folder, 
        Set-Location .\Bin\

        
        # enforce repeat collection to be a valid number (0 or greater)
        if ([Int]::TryParse($RepeatCollections, [ref]$null) -eq $false)
        {
            Microsoft.PowerShell.Utility\Write-Host "Please provide a valid number value for the RepeatCollections parameter (0 or greater)" -ForegroundColor Yellow
            break
        }
        else 
        {
            if (($RepeatCollections -lt 0) -or ($RepeatCollections -eq $null))
            {
                $RepeatCollections = 0
            }
        }

        if ($execution_counter -eq 0)
        {
            Write-SQLLogScoutTempLog "Initial collection running."
            Write-SQLLogScoutTempLog "Total Repeat collections: $RepeatCollections. This count is in addition to the initial collection. Thus the total LogScout collections will be $($RepeatCollections + 1)."
        }
        else 
        {
            Write-SQLLogScoutTempLog "Repeat collection running. Current iteration count: $execution_counter"
        }

        
        # if the user wants multiple executions of the script, then we need to set some parameters 
        if (($RepeatCollections -gt 0))
        {
            
        
            #if repeat collection is set to > 0, then we need to make sure the user has passed a custom output path value or use current path
            if ($CustomOutputPath -eq "PromptForCustomDir")
            {
                Microsoft.PowerShell.Utility\Write-Host "The default value 'PromptForCustomDir' for the CustomOutputPath parameter isn't a valid option when used with RepeatCollections. Specify 'UsePresentDir' or a valid path." -ForegroundColor Yellow
                break
            }

            #if repeat collection is set to > 0, then interactive prompts should be set to quiet
            $InteractivePrompts = "Quiet"


            #if repeat collection is set to > 0, then we need to make sure DeleteExistingOrCreateNew is not null or empty
            #if $DeleteExistingOrCreateNew isn't "DeleteDefaultFolder", "NewCustomFolder", then main script will validate that
            if([Int]::TryParse($DeleteExistingOrCreateNew, [ref]$null) -eq $true)
            {
                #convert the string to an integer and store it in the folders_to_preserve variable
                #this will be used to preserve the most recent folders and delete the rest
                $folders_to_preserve = [Int]::Parse($DeleteExistingOrCreateNew)

                Write-SQLLogScoutTempLog "Folders to keep was set to $folders_to_preserve by the user." 

                #if the value is a number, it behaves like a new custom folder to be created
                $DeleteExistingOrCreateNew = "NewCustomFolder"
            }
            elseif($DeleteExistingOrCreateNew -notin "DeleteDefaultFolder","NewCustomFolder")
            {
                #if the value is "DeleteDefaultFolder", then we will delete the default folder
                Microsoft.PowerShell.Utility\Write-Host "To run in continous mode (RepeatCollections), please provide a valid 'DeleteExistingOrCreateNew' value." -ForegroundColor Yellow
                break
            }

            # If repeat collection is set to > 0, then we need to make sure the user has passed all the parameters for time range
            if ($DiagStartTime -eq "0000" -or $DiagStopTime -eq "0000")
            {
                Microsoft.PowerShell.Utility\Write-Host "Please provide a valid start time (DiagStartTime) and stop time (DiagStopTime) parameters." -ForegroundColor Yellow
                break
            }
        

            #if repeat collection is set to > 0, then we need to make sure the user has passed a server name and scenario
            if (($true -eq [String]::IsNullOrWhiteSpace($ServerName)) -or ($true -eq [String]::IsNullOrWhiteSpace($Scenario)))
            {
                Microsoft.PowerShell.Utility\Write-Host "Please provide a valid server name and scenario for the diagnostic" -ForegroundColor Yellow
                break
            }
        }
        else 
        {
            #if the user has not provided a value for RepeatCollections, then DeleteExistingOrCreateNew should not be a number
            if([Int]::TryParse($DeleteExistingOrCreateNew, [ref]$null) -eq $true)
            {
                Microsoft.PowerShell.Utility\Write-Host "The 'DeleteExistingOrCreateNew' parameter cannot be a number if the 'RepeatCollections' parameter is less than 1. If you want to use repeated collections, specify a value of 1 or greater for RepeatCollections." -ForegroundColor Yellow
                break
            }
            
            
        }

        #create an object to keep track of how many times SQL LogScout will be executed if continuous mode/repeat collection is selected
        #if the user wants to delete the default folder, then we will set the folder overwrite to true
        $ExecutionCountObj = [PSCustomObject]@{
            CurrentExecCount = $execution_counter
            RepeatCollection= $RepeatCollections
            OverwriteFolder = $null}
        
        
        #if user needs to show help, do this
        if ($help)
        {
            .\SQLLogScoutPs.ps1 -help
        }
        # execute SQL LogScout with the parameters provided
        else 
        {
         
            # If repeat collection is set to > 0, then we will keep running the script until we reach RepeatCollections value or the user presses Ctrl+C
            .\SQLLogScoutPs.ps1 -Scenario $Scenario -ServerName $ServerName -CustomOutputPath $CustomOutputPath -DeleteExistingOrCreateNew $DeleteExistingOrCreateNew `
                                -DiagStartTime $DiagStartTime -DiagStopTime $DiagStopTime -InteractivePrompts $InteractivePrompts `
                                -ExecutionCountObject $ExecutionCountObj 
        }


        
        # Add the latest output folder used by LogScout to the array if in repeat mode and reset the global output folder variable
        if ($RepeatCollections -gt 0)
        {

            #if the user has not provided a value for folders to preserve, then we will preserve all the output folders
            # also this value can be reset to null later if the user has provided a number greater than the repeat collections
            if ($null -eq $folders_to_preserve)
            {
                Write-SQLLogScoutTempLog "Folders_to_Preserve is null. Will preserve all output folders."

            }
            
            #reset/correct the number of folders to preserve. 
            #if the user has provided a number, then we will use that number to preserve the folders
            #if the user has provided a number greater than the repeat collections, we won't delete any folders, just keep the ones created
            #if folders to keep is set to 0 folders, then we will default to 1
            if ($folders_to_preserve -eq 0)
            {
                $folders_to_preserve = 1
                Write-SQLLogScoutTempLog "Folders to keep was reset to: $folders_to_preserve" 
            }
            elseif ($folders_to_preserve -ge $RepeatCollections)
            {
                #set the folders to preserve to null, so we don't delete any folders
                Write-SQLLogScoutTempLog "Folders to keep was reset to 'null' since it's larger than RepeatCollecitons. No folders will be deleted." 
                $folders_to_preserve = $null
            }

            Write-SQLLogScoutTempLog "Folders to keep is set to: $folders_to_preserve" 

            #add the output folder to the array script level variable
            $script:output_folders_multiple_runs += $global:output_folder
            
            #log the output folders 
            Write-SQLLogScoutTempLog ("Output folders: `r`n`t`t`t" + ($script:output_folders_multiple_runs -Join "`r`n`t`t`t"))

            #reset the global output folder variable. use a string instead of a $null for debugging purposes
            $global:output_folder = "invalid_folder_path"

            # Get last write times for each folder using Get-Item
            $folderLastWriteTimes = @{}
            foreach ($folderPath in $script:output_folders_multiple_runs) 
            {
                #add both key and value in hash table if the folder exists
                if (Test-Path -Path $folderPath)
                {
                    $folderLastWriteTimes[$folderPath] = (Get-Item $folderPath).LastWriteTime
                }
            }

            # Preserve the most recent X folders and delete the remaining ones, but only if the value is greater than 0 or non-null
            # If the user has not provided a number, then we will not delete any folders
            if (($null -ne $folders_to_preserve) -or ($folders_to_preserve -gt 0))
            {
                
                # Sort folder paths based on last write time
                $sortedFolderPaths = $folderLastWriteTimes.GetEnumerator() | Sort-Object -Property Value -Descending |Select-Object -Property Value, Key


                # Preserve the most recent X folders and delete the remaining ones
                $deletedFolders = $sortedFolderPaths | Select-Object -Skip $folders_to_preserve

                # Print deleted folders
                foreach ($del_folder in $deletedFolders)
                {
                    Write-SQLLogScoutTempLog "Folder being deleted: $($del_folder.Key)"
                }

                # Clean up: Remove the folders
                $deletedFolders | ForEach-Object { Remove-Item -Path $_.Key -Force -Recurse }
            }
        }

        # Return to the original location
        Pop-Location

        # Increment the execution counter
        $execution_counter++

    } while ($execution_counter -le $RepeatCollections)

}
catch 
{
    Write-Host $PSItem.Exception.Message

    $exception_str = "Exception line # " + $($PSItem.InvocationInfo.ScriptLineNumber) + ", offset" + $($PSItem.InvocationInfo.OffsetInLine) + ", script ='" + $($PSItem.InvocationInfo.ScriptName) +"'"

    #write the exception to the temp log file and console
    Write-Host $exception_str
    Write-SQLLogScoutTempLog -Message $exception_str

}
finally 
{
    Pop-Location
}


# SIG # Begin signature block
# MIIoSAYJKoZIhvcNAQcCoIIoOTCCKDUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCF90W2/eJ7ZBUf
# vfShTP48GFkZXkdu1MdXTynfIIzLPKCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGigwghokAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIE4lT+PQxLHNc1tV6AGxBJMF
# pd8EyX+Ay4laRlRE7LA0MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0B
# AQEFAASCAQAnojHg3Z0Iit+NsegXqs8B1jwoXKfGzuYISUzkPaevZXTtHugLri2/
# 7Jdct2GQlu7Md2wEQKPjJg4avxlM02XGStHO1wOst7UxoeCCVcVshmWjrdy8Y3/7
# 4QW4SiPdUsN/2hJY2slnW3XZrwvbqfoOdKEY7Kr1cUptC2SefSa+z0EMaYzD2zCH
# iYlz32yXJpbblKIc1s490NxjuO4Pd2ky/Y7m2ojAH6/uyWW2bvsxRuLYo3U1cxgF
# PDi+MwgIXlRFiQZ+ZUcqSuoCpP4Oscd/hFmYR+wRMZGt3inxTmMNAJRY8XksHBak
# KbQHBiy7pR88ZfdJ/2970nOXQjABcaOhoYIXsDCCF6wGCisGAQQBgjcDAwExghec
# MIIXmAYJKoZIhvcNAQcCoIIXiTCCF4UCAQMxDzANBglghkgBZQMEAgEFADCCAVoG
# CyqGSIb3DQEJEAEEoIIBSQSCAUUwggFBAgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIEZ/o7akvLm7e9xuEw9pA+/g22+lnNnsBp3biMmI8q3oAgZm61+2
# jq4YEzIwMjQxMDE1MDYzNTQ3LjA1NFowBIACAfSggdmkgdYwgdMxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJ
# cmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1Mg
# RVNOOjU5MUEtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloIIR/jCCBygwggUQoAMCAQICEzMAAAH0F0aFwMs/OeUAAQAAAfQw
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MjQwNzI1MTgzMDU5WhcNMjUxMDIyMTgzMDU5WjCB0zELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQg
# T3BlcmF0aW9ucyBMaW1pdGVkMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046NTkx
# QS0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2UwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCnCE4TptCAL2qriMkZ
# fYDXKg5t+TSp61DySSP7mbftYHEOWxnmgmeN/Meymo+I4RXNnbLbKAaA1nf/F1lA
# 3t/0DVanUB2HmoddlmHdIFfwAG5zr1NvdwnkoJlxcOy5/CZd4KPzUTMkQhmq5V1X
# xJOVC54H9vUwhi3lEqKze7DN2V9KXRyQdsbOg73VhMqDogTGopiiMat4KimcgrE6
# +SvlVmyPZ/3kFvUsYS+6EEib8LsnKy8m8FlY22uynPJdWe6j6QMTJnCmSmGxHxm9
# 2L6z+lCKh+Z1tbVSrNaWpdBWChhdtpiQTJpKH+F4G3CPW2574ty45wcA+BvBm9Au
# SwporjqiS2t6A5Hh7SJywaIBZH0gv6fLiaUJQ0DzgXsYQRY4S+JuKDvCytNrplvO
# 4yzJOLYDPio9XdBGQWDFJunhHg4QqeKfwnPhcsjXBeEGEikwZ8DcFPznSepqbNKI
# PkvmnH5W18KLQwlNLYsMXU9pVnCXJVkhWNUcryiHYdgb1PboWNH38jzmLkTHGaEe
# nEzZn5SEl5kDovPjnab/7GsDjGt1hqzlybsVSHLbis8tUf4XL5nLAcCn1z2hZOu2
# N8gqosi9i2AlzjVDxbFtk9HsHW5+3wEWy/PZ05IuTE8MtxdbLXoA3Lve/SKkLEDB
# QQL2GyyLQt0HxOGI1//gD5FnywIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFCt0ZaEK
# 0Sw+J3UsnOxNotMpBt+bMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1Gely
# MF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lv
# cHMvY3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNy
# bDBsBggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBD
# QSUyMDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYB
# BQUHAwgwDgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQDdwdIPEkpQ
# OyBpwh9FfrS6A4NKGwGrC0RRFRtRd4OZhhJrmgWPfhG6NbeA54K385sM7jm9+mdg
# bk5LlijDCwXDX2CIIjolX5xwb+qozTyfEBJvPBa2q2ivNCImH26mwThNVl4pheZv
# LHtY3211tUisJ6VWPs/qJ8wdNIu3oGbKhLbGULZx+Ao88DXe9Ld66pSXrPB7sYCG
# N+M1eMqUThI1Ym92qCu/QZREqOqZqY2+GZIlqd7pNjOl0MJ6Crxp2UYfzkjURYqZ
# 8RFvWXMrLk4w7Z70iQCW/J2lS6fQLew0S2nR6GWJPRKtqryNxhUMfgDYL8xssEjC
# KSPCIUZDhKUUtPZOBvga++lxZXMHHAOj0hEHCnOeBvLNuGH3lRU6tAvattYescNI
# Td2B0vbK5odGBjsdhguzku2zfTBT066Hw3nhFS1roYVkXHkDi4hODIlxV1ZVo3Sq
# OzR4SPATI1S/RxEu4dYkF6OQx7epECG8KOeGujsMZFZoiV3J/NmqWfoWyctDduX5
# m9UlZNgm4v4hksjZKLcishF+Nxyfb1fYFf+/PYpxi5siMrpd9i+tlA3hcpue9KoE
# 0DAg9jbEl4Hij08MQUjatw9otTLPkhXsk/clGmCDfGxSq8UeVIbq4whaPAfQZAgj
# CsLbNHL6U1mw4qeu7LIcxBM/uPLlT3aoQTCCB3EwggVZoAMCAQICEzMAAAAVxedr
# ngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4
# MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3
# DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qls
# TnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLA
# EBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrE
# qv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyF
# Vk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1o
# O5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg
# 3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2
# TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07B
# MzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJ
# NmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6
# r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+
# auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3
# FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl
# 0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUH
# AgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0
# b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL
# /Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu
# 6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5t
# ggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfg
# QJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8s
# CXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCr
# dTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZ
# c9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2
# tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8C
# wYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9
# JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDB
# cQZqELQdVTNYs6FwZvKhggNZMIICQQIBATCCAQGhgdmkgdYwgdMxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJ
# cmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1Mg
# RVNOOjU5MUEtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQC/4tn9WDSzXtd6TiIb1H1z/v4AjqCB
# gzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEB
# CwUAAgUA6rgjjjAiGA8yMDI0MTAxNDIzMTExMFoYDzIwMjQxMDE1MjMxMTEwWjB3
# MD0GCisGAQQBhFkKBAExLzAtMAoCBQDquCOOAgEAMAoCAQACAh4MAgH/MAcCAQAC
# AhNQMAoCBQDquXUOAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKg
# CjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEBAFjGyroO
# i6SMXskuz/rbLh2BeQih0gk/FBrNwMdXE4D9D8OYpgG4YDA7kMdwhPV8aN/WydjW
# kDwxxvNPugbpsO3pMfgR6CRE6PXInPvbcIgkXjR9QwnKdUX0JVZRSG3XJIm3BZam
# /Ds/own00l+bXwdr0uVVaRCOb+ZjW2cO6iwmL4WR6gbJOkcn0dVfpxuYjXuauYHq
# /b6kkCvWocSYmYWuJ5WRnsiPrGHWoUuRvqNM2fpEV6EFgbLiV2GIvk0bMdEAiyGl
# Se+tO739aFkinP3w6D9Wbksf+F85VmNI6Wgu8tPTPxoHlzmx63bBdgLOb+CaEPAD
# 9W5BIROVgKEkZrQxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAfQXRoXAyz855QABAAAB9DANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCjhyyA
# Rbcai/b9Na/YRA4l8VehWaZyUDrcFWoI1hSGaTCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EID9YwnxuJpPqeO+SScHxDuFJAiLzKzq8gG9mDrREGNZrMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAH0F0aFwMs/OeUA
# AQAAAfQwIgQgJ9D9m7DkveZnVxyNI25adxwDnjqIRRxo7F4J7VBlP+MwDQYJKoZI
# hvcNAQELBQAEggIAeg7HuW0WXLTgPFfznaGT1QFiq25dmKR/Nv1G/SHEORDuJgOW
# H15m19po/6Jhs58Y9hrFGUTwcdboSmVk37kvXsNbpUTG9hZGzl97ehATG84/xeVl
# OB/+iw6OZK92tbmCIquD0oet5Ki8bOGQmxDlWnxODdalFHRq9KTU/de7AMfAQ6Ka
# VJESoa24lZv8HfrMbNtVpmhELy+zGXevlLsQ+Q4kljYpzuy3lyLPsXHYy5OeHQl/
# f/2tr9KaN4zK+PVX37pkJB/l4abuvhK72e93KnBKtlwRLzqaHEwZfYBWaC1ccogM
# whrUviIzU4koY26BYZqid6eqzILH2/CMfCFDlo4C5QOKxucETDgP5n0YlyZHeSS2
# yTXMSLQUHNuoIa1D/suHWTlXleTqe+AZ5iodSFljVKMLIkt6XAx7JaVQUSPz44XI
# F72TpZC87Y56sQ0IfkRM6YqwFCLBVuLCeEwXMNWYjiASiMMY8giWz74PTr5kJGfU
# PSHcf22DtHxIUyZF2YBKBVoiONJqKenFbAN5qL5PGF8B6Rb4dcoP9tY6Nh1btN9q
# t6/h5vbPzDvBOV8wNZGL4ZMqKth6YFrAvbrc8o7/+ccSMnHmiLZTwnCbG08kMqmB
# FRKKeq3igF6pOPTCYxuq/mLp1KPqAY3LrlCtHM/nOZTTev/cnyhrS25Soao=
# SIG # End signature block
